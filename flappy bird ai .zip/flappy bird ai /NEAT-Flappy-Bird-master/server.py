from flask import Flask, jsonify
import subprocess
import os

app = Flask(__name__)

@app.route('/start_game')
def start_game():
    try:
        subprocess.Popen(
            ["python3", "flappy_bird.py"],
            cwd="/Users/amanthakur/Documents/WORK/Projects/flappy bird ai /NEAT-Flappy-Bird-master/NEAT"
        )
        return jsonify({'status': 'success'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)})

if __name__ == "__main__":
    app.run(debug=True)
