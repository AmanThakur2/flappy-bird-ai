Normal game :- 
cd "/Users/amanthakur/Documents/WORK/Projects/flappy bird ai /NEAT-Flappy-Bird-master/flappy-bird-master"
python3 main.py   
cd "/Users/amanthakur/Documents/WORK/Projects/flappy bird ai /NEAT-Flappy-Bird-master"
python3 server.py   
python3 flappy_bird.py     


TO RUN :- CHANGE DIRECTORY, RUN SERVER.PY, AND START INDEX.HTML